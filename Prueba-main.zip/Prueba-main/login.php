<?php
// Incluir la conexión a la base de datos
include 'config.php';

session_start(); // Iniciar la sesión

// Verificar si se han enviado los datos del formulario
if (isset($_POST['Usuario']) && isset($_POST['password'])) {
    $usuario = $_POST['Usuario'];
    $password = $_POST['password'];

    // Evitar inyecciones SQL escapando los valores
    $usuario = $conexion->real_escape_string($usuario);
    $password = $conexion->real_escape_string($password);

    // Consulta para validar el usuario y la contraseña
    $sql = "SELECT * FROM usuarios WHERE usuario = '$usuario' AND password = '$password'";
    $resultado = $conexion->query($sql);

    // Verificar si se encontró un registro coincidente
    if ($resultado->num_rows == 1) {
        // Usuario y contraseña correctos, iniciar sesión
        $_SESSION['usuario'] = $usuario;

        // Redirigir a la página holamundo.php
        header("Location: holamundo.php");
        exit();
    } else {
        // Credenciales incorrectas, mostrar mensaje de error
        $error = "Usuario o contraseña incorrectos";
    }
}
