

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bancoop</title>
    <link rel="stylesheet" href="style1.css">
</head>
<body>
    <header>
        <div class="container">
            <div>
                <div>
                    <h1>BANCOOP</h1>
                    <p>Te ayuda a alcanzar tus metas</p>
                </div>
                <div>
                    <img src="descarga-fotor-bg-remover-20241004131314-Photoroom.png" alt="logo bancoop"> 
                </div>
            </div>
            <div>
                <p><a href="#">Créditos</a></p>
                <p><a href="#">Leasing</a></p>
                <p><a href="#">Ahorros</a></p>
                <p><a href="#">Servicio al cliente</a></p>
            </div>
        </div>
    </header>

    <main>
        <div class="container">
            <div>
                <form class="sign-in-form" method="POST" action="login.php" novalidate>
                    <div class="login">
                        <div class="bg-black left-title">
                            <h2>INGRESA A TU CUENTA</h2>
                        </div>
                        <div>
                            <div class="form-group">
                                <div><label for="usuario">Usuario:</label></div>       
                                <div><input type="text" id="usuario" name="Usuario" required></div>
                            </div>
                             <div class="form-group">
                                <div><label for="tipo">Tipo:</label></div>
                                <div>
                                    <select name="tipoCuenta" id="tipo">
                                        <option value="">Seleccione tipo de cuenta</option>
                                        <option value="Ahorros">Ahorros</option>
                                        <option value="Corriente">Corriente</option>
                                    </select>
                                </div>
                            </div> 
                            <div class="form-group">
                                <div><label for="password">Contraseña:</label></div>
                                <div><input type="password" id="password" name="password" required></div>
                            </div>
                            <div>
                                <button type="submit">Ingresar</button>
                                <button type="reset">Cancelar</button>
                            </div>
                        </div>
                    </div>

                    <?php if (isset($error)) { ?>
                        <p style="color:red;"><?php echo $error; ?></p>
                    <?php } ?>
                </form>
            </div>

            <div class="menu">
                <div>
                    <div class="bg-black left-title">
                        <h2><em>TRANSACCIONES</em></h2>
                    </div>
                    <div>
                        <div><p>Banco Personal</p></div>
                        <div><p>Banca Empresarial</p></div>
                        <div><p>Banca de Seguros</p></div>
                        <div><p>Pago de Facturas</p></div>
                    </div>
                </div>
                <div>
                    <div class="bg-black left-title">
                        <h2><em>TARJETAS</em></h2>
                    </div>
                    <div>
                        <div><p>Credi-Visa</p></div>
                        <div><p>Credi-Mastercard</p></div>
                    </div>
                </div>
            </div>

            <div class="contenido">
                <div class="card"> 
                    <div>
                        <h2 class="content-title">SOLICITA NUESTROS PRODUCTOS</h2>
                        <div><img src="card.png" alt="productos"></div>
                    </div>
                    <div>
                        <p>Ofrecemos una variedad de productos de alta calidad diseñados para satisfacer tus necesidades. Ya sea que busques tecnología de vanguardia, artículos para el hogar o soluciones personalizadas, estamos aquí para ayudarte.</p>
                    </div>
                </div>
                <div>
                    <div>
                        <h2 class="content-title">AHORRO ESTUDIANTIL</h2>
                        <img src="images.png" alt="ahorro estudiantil" class="icon">
                    </div>
                    <div>
                        <p>¡El futuro te espera! No dejes pasar esta oportunidad de invertir en ti mismo. Abre una cuenta de ahorro hoy mismo y comienza a construir tu patrimonio. ¡Te ofrecemos herramientas y consejos para que alcances tus objetivos!

</p>
                    </div>
                </div>
                <div>
                    <div>
                        <h2 class="content-title">CRÉDITO PARA ADQUISICIÓN DE VEHÍCULOS</h2>
                        <img src="images car.png" alt="crédito vehicular" class="icon">
                    </div>
                    <div class="relativo"></div>
                    <div>
                        <p>"¡Tu primer auto te espera! Con nuestro crédito para vehículos, podrás disfrutar de la libertad de tener tu propio medio de transporte. ¡Tasas bajas, plazos flexibles y trámites sencillos! Simula tu crédito ahora y comienza a vivir nuevas aventuras."</p>
                    </div>
                </div>
                <div>
                    <div>
                        <h2 class="content-title">CRÉDITO HIPOTECARIO</h2>
                    </div>
                    <img src="images-house.png" alt="hipoteca" class="icon">
                    <div>
                        <p>"Invierte en tu futuro y el de tu familia. Un crédito hipotecario es una inversión segura y rentable. ¡Conoce nuestros planes y comienza a construir tu patrimonio!".Adquiere tu vivienda de forma rápida y sencilla. Nuestro proceso de solicitud es ágil y te brindamos todo el asesoramiento que necesitas."</p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <div>
                <div><img src="descarga-fotor-bg-remover-20241004131314-Photoroom.png" alt="logo footer"></div>
                <div>
                    <p>Contáctenos</p>
                    <p>Línea Gratuita: 01-8000-000001</p>
                    <p>Bancoop - Entidad Financiera - Todos los derechos reservados</p>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
