<?php
// Datos de la base de datos
$host = 'database'; // O el nombre del contenedor de MySQL si usas Docker Compose
$usuario = 'root';    // Usuario de MySQL
$contraseña = 'docker'; // Contraseña de MySQL
$baseDeDatos = 'prueba_2';

// Conexión a MySQL con mysqli
$conexion = new mysqli($host, $usuario, $contraseña, $baseDeDatos);

// Verificar si la conexión fue exitosa
if ($conexion->connect_error) {
    die("Error en la conexión: " . $conexion->connect_error);
}
?>
